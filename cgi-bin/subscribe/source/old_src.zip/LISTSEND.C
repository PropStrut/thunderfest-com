
/*  LISTSEND.C  */

#include <stdio.h>
#include <string.h>
#include <process.h>
#include "listsend.h"
#include "cgi-util.h"


#define ADMIN_PASSWORD "sodtpass3"


char         RootDir[]="d:/webs/thunderfest/cgi-bin/subscribe/";
char         UserList[]="d:/webs/thunderfest/cgi-bin/subscribe/list.txt";
USER_RECORD  users[MAX_USERS];
int          user_count;
char         workbuffer[WORKBUFFER_LEN];


void output_page(char *msg)
{
static char fullname[256];

  // Output the HTML page header
  printf("Content-type: text/html\n\n");
//  // Copy the header of our HTML page to the user
//  strcpy(fullname, RootDir);
//  strcat(fullname, "header.html");
//  dump(fullname);
  // Copy the message to the user
  printf("%s\n", msg);
//  // Copy the footer of our HTML page to the user
//  strcpy(fullname, RootDir);
//  strcat(fullname, "footer.html");
//  dump(fullname);
}


void mystrip(char *str)
{
char tmp[50];

  // Take off a leading space (if there is one)
  if (str[0] == ' ') {
    strcpy(tmp, &str[1]);
    strcpy(str, tmp);
  }

  // Take off a leading double-quote
  if (str[0] == '"') {
    strcpy(tmp, &str[1]);
    strcpy(str, tmp);
  }

  // Take off a trailing double-quote
  if (str[strlen(str)-1] == '"')
    str[strlen(str)-1] = 0;
  if (str[strlen(str)-2] == '"')
    str[strlen(str)-2] = 0;
}


int read_database(void)
{
USER_RECORD user;
FILE *fp;
char *ptr;

  user_count = 0;
  if ((fp=fopen(UserList, "r")) == NULL)
    return 0;
  while (1) {
    // Get the data line
    fgets(workbuffer, WORKBUFFER_LEN, fp);
    if (feof(fp))
      break;
    // Parse the line
    ptr = strtok(workbuffer, ",");
    if (ptr)
      strcpy(user.address, ptr);
    ptr = strtok(NULL, ",");
    if (ptr)
      strcpy(user.name, ptr);
    ptr = strtok(NULL, ",");
    if (ptr)
      strcpy(user.affiliation, ptr);
    mystrip(user.address);
    mystrip(user.name);
    mystrip(user.affiliation);

    // If it's good data, add them to the RAM database
    if (goodemailaddress(user.address) != 0) {
      strcpy(users[user_count].address, user.address);
      strcpy(users[user_count].name, user.name);
      strcpy(users[user_count].affiliation, user.affiliation);
      user_count++;
    }
  }

  fclose(fp);
  return 1;
}


int main(int argc, char *argv[])
{
static char text[65536];
static char sendbtn[20], subject[256], password[256], textfile[256], blat[256];
static char sender[128]="ivanhoe@gatecom.com";
static char server[128]="mail.gatecom.com";
static char from[128]="webmaster@thunderfest.com";
static char organization[128]="Spirit Of Detroit THUNDERFEST";
FILE *fp;
int u;

  strcpy(blat, RootDir);
  strcat(blat, "blat.exe");

  // Get the FORM data
  cgiinit();
  getentry(password, "userPassword");
  getentry(subject, "userSubject");
  getentry(text, "userText");
  getentry(sendbtn, "Send");             // The SEND button
  if (strcmp(password, ADMIN_PASSWORD) != 0) {
    output_page("<P>Wrong password.");
    return 0;
  }
  if (strlen(subject) < 1) {
    output_page("<P>You must enter a subject.");
    return 0;
  }
  if (strlen(text) < 1) {
    output_page("<P>You must enter a text message.");
    return 0;
  }

  // Delete the work file
  unlink(textfile);

  // Copy userText to the work message file ('textfile' as "msgbody.wrk")
  strcpy(workbuffer, RootDir);
  strcat(workbuffer, "msgbody.wrk");
  strcpy(textfile, workbuffer);
  if ((fp=fopen(textfile, "w")) == NULL) {
    output_page("Couldn't open the temp file.");
    return 0;
  }
  fprintf(fp, "%s", text);
  fclose(fp);

  // Read in data file
  if (read_database() == 0) {
    output_page("<P>Missing \"list.txt\".  Please alert the webmaster!");
    return 0;
  }

  // Do the action
  sprintf(workbuffer, "Running BLAT for %d subscribers.<P>", user_count);
  output_page(workbuffer);
  for (u=0; u<user_count; u++) {
    printf(".");
    //printf("%s<BR>\n", users[u].address);
    sprintf(workbuffer, "%s \"%s\" -s \"%s\" -t %s -f %s -i %s -o \"%s\" -server %s -noh -q",
      blat, textfile, subject, users[u].address, sender, from, organization, server);
    system(workbuffer);
  }

  // Delete the work file
  unlink(textfile);

  printf("<P>FINISHED");
  return 1;
}


